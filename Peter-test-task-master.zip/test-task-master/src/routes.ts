
export enum RoutesEnum {
    home = '/',
    create = '/create',
    details = '/details/:id',
  };