export type Post = {
  title: string,
  body: string,
  userId: number,
  id?: number
}