export const ROUTES = {
  HOME_PAGE: "/",
  CREATE_PAGE: '/create',
  DETAILS_PAGE: '/details/:id'
}